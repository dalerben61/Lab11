from flask import Flask, render_template
import sqlite3
import base64
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/option1')
def finding():
    student_list = []
    url_list = []

    for i in range(1, 43):
        conn = sqlite3.connect("week10.db")
        cur = conn.cursor()
        str_id = str(i)
        query_to_execute = "SELECT id, Link, Student FROM Lab10 WHERE id = " + str_id
        joined_query = ''.join(query_to_execute)
        cur.execute(joined_query)
        rows = cur.fetchall()
        for row in rows:
            pass
        student_name = row[2]
        url64 = row[1]
        decoded_url = base64.urlsafe_b64decode(url64)
        string_url = bytes.decode(decoded_url)
        if student_name is None:
            student_name = "*No Name Entry*"

        conn.close()

        student_list.append(student_name)
        url_list.append(string_url)

    pairs_list = zip(student_list, url_list)

    return render_template('findStudent.html', pairs=pairs_list)


@app.route('/option2')
def information():
    student_list = []
    url_list = []
    city_list = []
    country_list = []

    for i in range(1, 43):
        conn = sqlite3.connect("week10.db")
        cur = conn.cursor()
        str_id = str(i)
        query_to_execute = "SELECT * FROM Lab10 WHERE id = " + str_id
        joined_query = ''.join(query_to_execute)
        cur.execute(joined_query)
        rows = cur.fetchall()
        for row in rows:
            pass
        city_name = row[2]
        country_name = row[3]
        student_name = row[4]
        url64 = row[1]
        decoded_url = base64.urlsafe_b64decode(url64)
        string_url = bytes.decode(decoded_url)
        if student_name is None:
            student_name = "*No Name Entry*"

        conn.close()

        city_list.append(city_name)
        country_list.append(country_name)
        student_list.append(student_name)
        url_list.append(string_url)

    info_list = zip(student_list, url_list, city_list, country_list)

    return render_template('displayAll.html', infos=info_list)


if __name__ == '__main__':
    app.run(debug=True)
